# Core Collector Utility

*** note
**Warning: This document is old & has moved.  Please update any links:**<br>
https://chromium.googlesource.com/chromiumos/platform2/+/HEAD/crash-reporter/core-collector/README.md
***

This is a basic utility to help read, strip, and convert coredumps into
minidumps, similar to the core2md utility.

It's not a collector in the same sense as all the other collector modules in
the crash-reporting project.
It probably should have used a different program name in hindsight.
